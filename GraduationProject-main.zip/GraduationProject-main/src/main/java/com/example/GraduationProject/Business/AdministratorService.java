package com.example.GraduationProject.Business;


import com.example.GraduationProject.Business.Entity.Administrator;
import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.SessionScope;

@SessionScope
@Service
public class AdministratorService {

    Administrator admin;


}
