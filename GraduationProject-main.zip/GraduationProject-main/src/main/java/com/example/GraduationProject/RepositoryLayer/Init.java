package com.example.GraduationProject.RepositoryLayer;

import com.example.GraduationProject.Business.Entity.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.util.List;


/*@Component
public class Init implements CommandLineRunner {


    @Autowired
    ProductRepository prodrepo;

*//*    public void saveProduct() {
        product.setPrice(20);
        product.setSize("M");
        product.setDescription("Floral dress");
        prodrepo.save(product);
    }

    public void saveProduct(){
        prodrepo.save(new Product("Floral dress",20,"M" ));
        prodrepo.save(new Product("dress",80,"M"));
        prodrepo.save(new Product("Floral dress",100,"M"));
    }*//*


    public void run(String... args) throws Exception {
        prodrepo.saveAll(List.of(
                new Product("Floral dress", 50, "M"),
                new Product("Dotted dress", 180, "S"),
                new Product("Jeans", 220, "XXL"),
                new Product("Jacket", 200, "L"),
                new Product("Satin dress", 100, "Ss"),
                new Product("shirt", 130, "M"))
        );

        System.out.println("Data Saved");
    }*/


